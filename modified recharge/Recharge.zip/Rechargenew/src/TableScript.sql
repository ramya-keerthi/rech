CREATE TABLE RechargeInfo(
Rech_Id VARCHAR2(20),
name VARCHAR2(20),
mobileNo NUMBER,
status VARCHAR2(20),
planName varchar2(20),
amount NUMBER);

CREATE SEQUENCE rechId_sequence
START WITH 1000;